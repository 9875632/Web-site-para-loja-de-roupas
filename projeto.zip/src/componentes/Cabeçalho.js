import React from 'react';

function Cabeçalho() {
  return (
    <header className="cabeçalho">
      <h1>Loja de Roupas Masculinas</h1>
    </header>
  );
}

export default Cabeçalho;