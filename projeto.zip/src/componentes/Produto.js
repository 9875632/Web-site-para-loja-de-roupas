import React from 'react';

function Produto({ nome, imagem, descricao }) {
  return (
    <div className="produto-card">
      <img src={imagem} alt={nome} />
      <h3>{nome}</h3>
      <p>{descricao}</p>
    </div>
  );
}

export default Produto;

