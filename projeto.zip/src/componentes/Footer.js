import React from 'react';

function Footer() {
  return (
    <footer className="footer">
      <p>Loja de Roupas Masculinas</p>
    </footer>
  );
}

export default Footer;