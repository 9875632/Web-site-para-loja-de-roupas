import React from 'react';
import './App.css';
import Header from './componentes/Cabeçalho';
import Produto from './componentes/Produto';
import Footer from './componentes/Footer';

function App() {
  return (
    <div>
      <Header />
      <div className="produto">
        <Produto
          nome="Camiseta Básica"
          imagem="https://static.netshoes.com.br/produtos/kit-camiseta-basica-c-5-pecas-masculina/34/MSX-0007-134/MSX-0007-134_zoom2.jpg?ts=1599221767&"
          descricao="Camiseta masculina de alta qualidade."
        />
        <Produto
          nome="Jaqueta de Couro"
          imagem="https://th.bing.com/th/id/OIP.lkCm3aQPdEthgBFzyczn-QHaHa?w=500&h=500&rs=1&pid=ImgDetMain"
          descricao="Jaqueta moderna e elegante."
        />
        <Produto
          nome="Calça Jeans"
          imagem="https://th.bing.com/th/id/OIP.KVV1vuGqvZpPA8CQO_Tt-AHaG1?rs=1&pid=ImgDetMain"
          descricao="Calça jeans confortável para o dia a dia."
        />
      </div>
      <Footer />
    </div>
  );
}

export default App;
